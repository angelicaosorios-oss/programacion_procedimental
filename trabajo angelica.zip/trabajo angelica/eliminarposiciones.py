reliquiasantiguas = ["juansito45años soltero en busca de una bandida", "mateo35años casado con 2 hijos solo pa mi", "carlitos41 viudo en espera de mi"]
reliquiasantiguas.pop(1)
print(reliquiasantiguas)