mylist = ["enero", "febrero", "marzo"]
print(type(mylist))
meses=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"]
print (meses[7:11])

frutas=["manzana","banana","cereza","durazno","kiwi"]
print(frutas[2:4])

